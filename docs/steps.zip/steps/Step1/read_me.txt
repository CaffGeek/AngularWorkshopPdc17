=================
 ANGULAR ACADEMY
=================

Workshop App: The Angular Store 
Using the Angular CLI

You need to reinstall the npm dependencies first:
npm install
or
yarn

Run the app with:
ng serve -port 10001

Then navigate to http://localhost:10001/
The app will automatically reload if you change any of the source files

---------------------
www.angularacademy.ca
---------------------
