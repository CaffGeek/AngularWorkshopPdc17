import { Product } from './../products/product.interface';
import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptionsArgs } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';

@Injectable()
export class ProductService {

    private apiEndpoint: string = "http://storerestservice.azurewebsites.net/api/products/";

    private products: Product[];

    constructor(private http: Http) { }

    getProducts(): Observable<Product[]> {
        if (this.products) {
            // Get products from local cache
            return Observable.of(this.products);
        } else {
            // Get products from server     
            return this.http
                .get(this.apiEndpoint)
                .do(console.log)
                .map(results => {
                    this.products = results.json()
                    return this.products;
                })
                .catch(this.handleError);
        }
    }

    private handleError(error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

}