import { Product } from './../products/product.interface';
import { Injectable } from '@angular/core';

@Injectable()
export class FavouriteService {

    constructor() { }

    private favourites: Set<Product> = new Set();

    addToFavourites(product: Product): void {
        this.favourites.add(product);
    }

    getFavouritesNb() : number {
        return this.favourites.size;
    }
}