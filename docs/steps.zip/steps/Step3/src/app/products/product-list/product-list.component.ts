import { Observable } from 'rxjs/Observable';
import { FavouriteService } from './../../services/favourite.service';
import { ProductService } from './../../services/product.service';
import { Product } from './../product.interface';
import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css'],
    encapsulation: ViewEncapsulation.Emulated,
    providers: [ProductService]
})
export class ProductListComponent implements OnInit {

    title: string = "Products";
    products: Product[] = [];
    products$: Observable<Product[]>;
    selectedProduct: Product;
    sorter: string = "-price";
    asc:boolean = true;
    searchName: string = "";
    productsNb: number;

    filterProducts(lst: Product[]): Product[] {
        this.productsNb = lst.length;
        return lst
                .filter(p => p.name.toLowerCase()
                        .includes(this.searchName.toLowerCase()));
    }
    
    pageSize: number = 5;
    start: number = 0;
    end: number = this.pageSize;

    nextPage(): void {
        this.start += this.pageSize;
        this.end += this.pageSize;
    }

    previousPage(): void {
        this.start -= this.pageSize;
        this.end -= this.pageSize;
    }

    sortList(propertyName:string): void {
        if(!this.asc) {
            propertyName = "-" + propertyName;
        }
        this.sorter = propertyName;
        this.asc = !this.asc;
    }

    onSelect(product: Product): void {
        this.selectedProduct = product;
    }

    message: string = "";

    newFavourite(product: Product): void {
        this.message = `Product
                        ${product.name} 
                        added to your favourites!`;
    }

    get favourites(): number {
        return this.favouriteService.getFavouritesNb();
    }

    constructor(
        private productService: ProductService,
        private favouriteService: FavouriteService)
    {}

    ngOnInit() {
        this.products$ = this.productService.getProducts();

    //    this._productService
    //             .getProducts()
    //             .subscribe(
    //                 data => this.products = data
    //             );
    }
}
