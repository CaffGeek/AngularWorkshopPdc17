import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { OrderBy } from './orderBy.pipe';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from "@angular/common";

@NgModule({
    imports: [
        FormsModule,
        CommonModule
    ],
    exports: [ProductListComponent],
    declarations: [
        ProductDetailComponent,
        ProductListComponent,
        OrderBy
    ],
    providers: [],
})
export class ProductsModule { }
